-- Validacion del DSR. Cambiar :ref por el dia de referencia que muestra el reporte (Refresh date[Fecha Ref]).

-- A) Dia de referencia: ultimo dia con facturas anterior a hoy (hora de Panama)
SELECT MAX(invoice_date) AS fecha_ref
FROM brewdat_uc_delta_maz_prod.gld_maz_sales_sell_in.pa_invoice
WHERE invoice_date < CAST(from_utc_timestamp(current_timestamp(), 'America/Panama') AS DATE);

-- B) Dia, Mes, YTD y sus equivalentes del anio anterior (HL y NTO), total compania
WITH p AS (SELECT DATE'2026-10-02' AS ref),      -- <-- poner aqui el dia de referencia
f AS (
  SELECT invoice_date, total_volume AS hl, net_revenue_amount AS nto
  FROM brewdat_uc_delta_maz_prod.gld_maz_sales_sell_in.pa_invoice
  WHERE invoice_date >= DATE'2025-01-01'
    AND (op_ind IS NULL OR op_ind NOT IN ('D', 'DELETE'))
)
SELECT
  ROUND(SUM(CASE WHEN invoice_date = ref THEN hl END), 2)                                             AS hls_dia,
  ROUND(SUM(CASE WHEN invoice_date = add_months(ref, -12) THEN hl END), 2)                            AS hls_dia_ly,
  ROUND(SUM(CASE WHEN invoice_date BETWEEN trunc(ref, 'MM') AND ref THEN hl END), 2)                  AS hls_mes,
  ROUND(SUM(CASE WHEN invoice_date BETWEEN add_months(trunc(ref, 'MM'), -12) AND add_months(ref, -12) THEN hl END), 2) AS hls_mes_ly,
  ROUND(SUM(CASE WHEN invoice_date BETWEEN trunc(ref, 'YYYY') AND ref THEN hl END), 2)                AS hls_ytd,
  ROUND(SUM(CASE WHEN invoice_date BETWEEN add_months(trunc(ref, 'YYYY'), -12) AND add_months(ref, -12) THEN hl END), 2) AS hls_ytd_ly,
  ROUND(SUM(CASE WHEN invoice_date BETWEEN trunc(ref, 'MM') AND ref THEN nto END), 2)                 AS nto_mes,
  ROUND(SUM(CASE WHEN invoice_date BETWEEN trunc(ref, 'YYYY') AND ref THEN nto END), 2)               AS nto_ytd
FROM f CROSS JOIN p;

-- C) Dias habiles del mes de referencia y del mismo mes del anio anterior
SELECT date_format(date, 'yyyy-MM') AS mes, SUM(valid_trading_days_mtd) AS td_month,
       MAX(trading_days_month) AS td_month_tabla
FROM brewdat_uc_maz_prod.slv_maz_masterdata_manual.pa_trading_days_calendar
WHERE date_format(date, 'yyyy-MM') IN ('2026-10', '2025-10')
GROUP BY 1 ORDER BY 1;

-- D) Tamanio de las dos tablas de ventas del modelo (filas despues de agrupar)
SELECT 'Ventas Dia' AS tabla, COUNT(*) AS filas FROM (
  SELECT invoice_date, sold_to_customer_short_code, product_short_code
  FROM brewdat_uc_delta_maz_prod.gld_maz_sales_sell_in.pa_invoice
  WHERE (invoice_date >= DATE'2026-10-01' OR invoice_date BETWEEN DATE'2025-10-01' AND DATE'2025-10-31')
  GROUP BY 1, 2, 3)
UNION ALL
SELECT 'Ventas Mes', COUNT(*) FROM (
  SELECT YEAR(invoice_date), MONTH(invoice_date), sold_to_customer_short_code, product_short_code
  FROM brewdat_uc_delta_maz_prod.gld_maz_sales_sell_in.pa_invoice
  WHERE (invoice_date >= DATE'2026-01-01' AND invoice_date < DATE'2026-10-01')
     OR (invoice_date >= DATE'2025-01-01' AND invoice_date < DATE'2025-10-01')
  GROUP BY 1, 2, 3, 4);
