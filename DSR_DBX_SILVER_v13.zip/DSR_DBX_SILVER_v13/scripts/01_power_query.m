// DSR SILVER v5 sobre Databricks (mes de reporte desde SAP silver) - consultas de Power Query (una consulta por bloque)

// ============================================================================
// [Parametros] DatabricksHost   (parametro de texto)
// ============================================================================
"adb-0000000000000000.0.azuredatabricks.net" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]

// ============================================================================
// [Parametros] DatabricksHttpPath   (parametro de texto)
// ============================================================================
"/sql/1.0/warehouses/0000000000000000" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]

// ============================================================================
// [Parametros] CuotaEsquema   (parametro de texto)
// ============================================================================
"brz_maz_sales_manual" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]

// ============================================================================
// [Parametros] TradingDaysCatalogo   (parametro de texto)
// ============================================================================
"brewdat_uc_maz_prod" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]

// ============================================================================
// [Parametros] TradingDaysEsquema   (parametro de texto)
// ============================================================================
"slv_maz_masterdata_manual" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]

// ============================================================================
"PENDIENTE" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]

// ============================================================================
// [Parametros] CatalogoPedidos   (parametro de texto: catalogo de pa_sales_order_detail)
// ============================================================================
"brewdat_uc_maz_prod" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]

// ============================================================================
// [Parametros] IncluirParcheZT0   (parametro logico: true = suma el volumen de S624100ZT0 desde silver)
// ============================================================================
true meta [IsParameterQuery=true, Type="Logical", IsParameterQueryRequired=true]

// ============================================================================
// [Funciones] fnTabla   (sin carga al modelo)
// ============================================================================
(catalogo as text, esquema as text, tabla as text) as table =>
let
    Origen = Databricks.Catalogs(DatabricksHost, DatabricksHttpPath, [Catalog = null, Database = null, EnableAutomaticProxyDiscovery = null]),
    Cat = Origen{[Name = catalogo, Kind = "Database"]}[Data],
    Esq = Cat{[Name = esquema, Kind = "Schema"]}[Data],
    Tab = Esq{[Name = tabla, Kind = "Table"]}[Data]
in
    Tab

// ============================================================================
// [Funciones] fnCodigo   (sin carga al modelo)
// ============================================================================
(v as any) as nullable text =>
    // Codigo de cliente / material / documento como texto y sin ceros a la izquierda
    if v = null then null else Text.TrimStart(Text.Trim(Text.From(v)), "0")

// ============================================================================
// [Funciones] fnFecha   (sin carga al modelo)
// ============================================================================
(v as any) as nullable date =>
    // Acepta date, datetime o texto (yyyy-MM-dd, yyyy.MM.dd, yyyyMMdd)
    if v = null then null
    else if v is date then v
    else if v is datetime or v is datetimezone then Date.From(v)
    else
        let
            t = Text.Replace(Text.Trim(Text.From(v)), ".", "-"),
            t2 = if Text.Length(t) = 8 and not Text.Contains(t, "-")
                 then Text.Start(t, 4) & "-" & Text.Middle(t, 4, 2) & "-" & Text.End(t, 2) else Text.Start(t, 10)
        in
            try Date.FromText(t2, [Format = "yyyy-MM-dd"]) otherwise null

// ============================================================================
// [Funciones] fnUltimaVersion   (sin carga al modelo)
// ============================================================================
(t as table, llaves as list) as table =>
// Ultima version de cada llave. Las tablas gold cargan con MERGE: no borran filas viejas y solo cambian
// __update_utc_ts en las filas que cambiaron. Por eso se toma el MAX de __update_utc_ts POR LLAVE (no el MAX global).
let
    Ultima = Table.Group(t, llaves, {{"__u_ts", each List.Max([__update_utc_ts])}}),
    LlavesU = List.Transform(llaves, each "__u_" & _),
    Ren = Table.RenameColumns(Ultima, List.Zip({llaves, LlavesU})),
    Unidas = Table.Join(t, llaves & {"__update_utc_ts"}, Ren, LlavesU & {"__u_ts"}, JoinKind.Inner),
    Res = Table.RemoveColumns(Unidas, LlavesU & {"__u_ts"})
in
    Res

// ============================================================================
// [Funciones] fnParcheZT0   (sin carga al modelo)
// ============================================================================
(desde as date, hasta as date) as table =>
// >>> PARCHE TEMPORAL S624100ZT0 (23-oct-2026). pa_invoice trae en 0 el volumen de producto gratis de la
// cuenta S624100ZT0 (su filtro de regalias solo toma S6241000T0 / S624102HT0). Aqui se lee desde silver
// (GLPCA + VBRP + VBRK) con la misma regla del query espejo v4 validado contra el cierre: utilizaciones BTL, sin PAC.
// Fecha = fecha contable (budat). Cliente = pagador (kunrg). Devuelve las mismas columnas que pa_invoice agrupado.
// QUITAR cuando el equipo corrija pa_invoice: poner el parametro IncluirParcheZT0 = false (si no, se cuenta doble).
let
    Vacia = #table(type table [invoice_date = date, sold_to_customer_short_code = text, product_short_code = text, hl = number, nto = number], {}),
    Origen = Databricks.Catalogs(DatabricksHost, DatabricksHttpPath, [Catalog = null, Database = null, EnableAutomaticProxyDiscovery = null]),
    Cat = Origen{[Name = "brewdat_uc_delta_maz_prod", Kind = "Database"]}[Data],
    Ini = Date.ToText(desde, [Format = "yyyy-MM-dd", Culture = "en-US"]),
    Fin = Date.ToText(hasta, [Format = "yyyy-MM-dd", Culture = "en-US"]),
    // Rendimiento: VBRP y VBRK filtrados por fecha (erdat / fkdat) con 45 dias de margen, no las tablas completas
    IniM = Date.ToText(Date.AddDays(desde, -45), [Format = "yyyy-MM-dd", Culture = "en-US"]),
    FinM = Date.ToText(Date.AddDays(hasta, 45), [Format = "yyyy-MM-dd", Culture = "en-US"]),
    Sql = "SELECT CAST(g.budat AS DATE) AS invoice_date, k.kunrg AS sold_to_customer_short_code, p.matnr AS product_short_code, "
        & "SUM(COALESCE(p.volum, 0) * CASE WHEN g.drcrk = 'H' THEN -1 ELSE 1 END) / 100000 AS hl, CAST(0 AS DOUBLE) AS nto "
        & "FROM brewdat_uc_delta_maz_prod.slv_maz_finance_sap_pr3.copecac_glpca g "
        & "JOIN (SELECT vbeln, posnr, matnr, volum, vkaus FROM brewdat_uc_delta_maz_prod.slv_maz_sales_sap_pr3.copecac_vbrp WHERE erdat BETWEEN '" & IniM & "' AND '" & FinM & "') p ON p.vbeln = g.refdocnr AND p.posnr = g.posnr "
        & "LEFT JOIN (SELECT vbeln, kunrg FROM brewdat_uc_delta_maz_prod.slv_maz_sales_sap_pr3.copecac_vbrk WHERE fkdat BETWEEN '" & IniM & "' AND '" & FinM & "') k ON k.vbeln = g.refdocnr "
        & "WHERE g.rbukrs = 'DC00' AND g.racct = 'S624100ZT0' "
        & "AND g.budat BETWEEN '" & Ini & "' AND '" & Fin & "' "
        & "AND TRIM(COALESCE(p.vkaus, '')) IN ('D0','D6','D8','D9','D1','D2','D7','C2','D3','D4','D5','R4') "
        & "GROUP BY CAST(g.budat AS DATE), k.kunrg, p.matnr",
    Datos = if IncluirParcheZT0 and hasta >= desde then Value.NativeQuery(Cat, Sql, null, [EnableFolding = false]) else Vacia
in
    Datos

// ============================================================================
// [Funciones] fnVentasSilver   (sin carga al modelo)
// ============================================================================
(desde as date, hasta as date) as table =>
// DSR SILVER: ventas leidas de SAP silver (GLPCA + VBRP + VBRK) con la logica del query espejo v4,
// validado al centavo contra el cierre de septiembre (ventas_cierre). Se usa SOLO para el mes de reporte.
// Fecha = fecha contable (budat), como el legado. Cliente = solicitante (VBRK.kunag).
// Volumen = HL reportado del cierre: vendido + trade E5 + regalias BTL sin PAC (S6241000T0 / S624100ZT0 / S624102HT0) + rewards R4.
// NTO = GSI - descuentos - excise del mes (pa_excise_rules) x HL.
// Rendimiento (v3): VBRK y VBRP se filtran por fecha (fkdat / erdat) con 45 dias de margen alrededor del periodo,
// para no unir las tablas completas.
// v5 HIBRIDO: a lo de GLPCA se suman las facturas que ya estan en VBRK/VBRP de silver pero que aun no tienen
// lineas en GLPCA (GLPCA carga ~5 veces al dia; VBRK/VBRP llegan antes). Solo volumen (NTO = 0 hasta que llegue GLPCA).
// Reglas validadas el 27-oct contra GLPCA (20 al 27-oct, diferencia <= 0.01 HL salvo 2 dias): clases de factura con signo,
// sin PAC ni E5, materiales < 1000000. Cuando GLPCA carga la factura, sale de 'pend' y se cuenta por GLPCA (sin doble conteo).
// v8: primero se buscan las facturas sin GLPCA (LEFT ANTI JOIN, no NOT IN) y solo de esas se leen las lineas de VBRP.
// Devuelve las mismas columnas que pa_invoice para que el resto de la consulta no cambie.
let
    Vacia = #table(type table [invoice_date = date, sold_to_customer_short_code = text, product_short_code = text,
        total_volume = number, net_revenue_amount = number, op_ind = text], {}),
    Origen = Databricks.Catalogs(DatabricksHost, DatabricksHttpPath, [Catalog = null, Database = null, EnableAutomaticProxyDiscovery = null]),
    Cat = Origen{[Name = "brewdat_uc_delta_maz_prod", Kind = "Database"]}[Data],
    Ini = Date.ToText(desde, [Format = "yyyy-MM-dd", Culture = "en-US"]),
    Fin = Date.ToText(hasta, [Format = "yyyy-MM-dd", Culture = "en-US"]),
    IniM = Date.ToText(Date.AddDays(desde, -45), [Format = "yyyy-MM-dd", Culture = "en-US"]),
    FinM = Date.ToText(Date.AddDays(hasta, 45), [Format = "yyyy-MM-dd", Culture = "en-US"]),
    IniG = Date.ToText(Date.AddDays(desde, -10), [Format = "yyyy-MM-dd", Culture = "en-US"]),
    Sql = "WITH cuentas AS ( SELECT gl_account_code AS cuenta, cognos_account_name AS clase_cta "
        & "FROM brewdat_uc_delta_maz_prod.slv_maz_masterdata_manual.pa_general_ledger_accounts ), "
        & "excise AS ( SELECT regexp_replace(sku, '^0+', '') AS material, CAST(date_since AS DATE) AS mes, MAX(excise) AS excise "
        & "FROM brewdat_uc_delta_maz_prod.slv_maz_masterdata_manual.pa_excise_rules GROUP BY 1, 2 ), "
        & "glpca AS ( SELECT racct, budat, drcrk, hsl, runit, refdocnr, posnr "
        & "FROM brewdat_uc_delta_maz_prod.slv_maz_finance_sap_pr3.copecac_glpca "
        & "WHERE rbukrs = 'DC00' AND budat BETWEEN '" & Ini & "' AND '" & Fin & "' AND racct IN (SELECT cuenta FROM cuentas) ), "
        & "vbrk AS ( SELECT vbeln, kunag FROM brewdat_uc_delta_maz_prod.slv_maz_sales_sap_pr3.copecac_vbrk "
        & "WHERE fkdat BETWEEN '" & IniM & "' AND '" & FinM & "' ), "
        & "vbrp AS ( SELECT vbeln, posnr, matnr, vkaus, volum FROM brewdat_uc_delta_maz_prod.slv_maz_sales_sap_pr3.copecac_vbrp "
        & "WHERE erdat BETWEEN '" & IniM & "' AND '" & FinM & "' ), "
        & "vbrk_p AS ( SELECT vbeln, fkart, kunag, CAST(fkdat AS DATE) AS dia, op_ind, "
        & "ROW_NUMBER() OVER (PARTITION BY vbeln ORDER BY source_commit_ts DESC) AS rn "
        & "FROM brewdat_uc_delta_maz_prod.slv_maz_sales_sap_pr3.copecac_vbrk "
        & "WHERE fkdat BETWEEN '" & Ini & "' AND '" & Fin & "' AND vkorg = 'DC01' ), "
        & "glpca_docs AS ( SELECT DISTINCT refdocnr FROM brewdat_uc_delta_maz_prod.slv_maz_finance_sap_pr3.copecac_glpca "
        & "WHERE rbukrs = 'DC00' AND budat BETWEEN '" & IniG & "' AND '" & FinM & "' AND refdocnr IS NOT NULL ), "
        & "pendk AS ( SELECT k.vbeln, k.fkart, k.kunag, k.dia FROM vbrk_p k "
        & "LEFT ANTI JOIN glpca_docs g ON g.refdocnr = k.vbeln "
        & "WHERE k.rn = 1 AND UPPER(TRIM(COALESCE(k.op_ind, ''))) NOT IN ('D', 'DELETE') ), "
        & "vbrp_p AS ( SELECT vbeln, posnr, matnr, volum, vkaus, op_ind, "
        & "ROW_NUMBER() OVER (PARTITION BY vbeln, posnr ORDER BY source_commit_ts DESC) AS rn "
        & "FROM brewdat_uc_delta_maz_prod.slv_maz_sales_sap_pr3.copecac_vbrp "
        & "WHERE erdat BETWEEN '" & IniM & "' AND '" & FinM & "' AND vbeln IN (SELECT vbeln FROM pendk) ), "
        & "pend AS ( SELECT k.dia, k.kunag AS cliente, regexp_replace(p.matnr, '^0+', '') AS material, "
        & "SUM(CASE WHEN k.fkart IN ('ZNP1', 'ZNO5', 'ZNS2', 'ZNS4', 'ZNO1', 'ZNOB') THEN p.volum "
        & "WHEN k.fkart IN ('ZND2', 'ZND4', 'ZNDB', 'ZNNE', 'ZNSD', 'ZNS6') THEN -p.volum ELSE 0 END) / 100000 AS hl "
        & "FROM pendk k JOIN vbrp_p p ON p.vbeln = k.vbeln "
        & "WHERE p.rn = 1 AND UPPER(TRIM(COALESCE(p.op_ind, ''))) NOT IN ('D', 'DELETE') "
        & "AND try_cast(p.matnr AS BIGINT) < 1000000 AND TRIM(COALESCE(p.vkaus, '')) NOT IN ('PAC', 'E5') "
        & "GROUP BY 1, 2, 3 ), "
        & "base AS ( SELECT CAST(g.budat AS DATE) AS dia, k.kunag AS cliente, regexp_replace(p.matnr, '^0+', '') AS material, "
        & "c.clase_cta, g.racct AS cuenta, COALESCE(e.excise, 0) AS excise, TRIM(COALESCE(p.vkaus, '')) AS util, "
        & "COALESCE(g.hsl, 0) AS hsl, COALESCE(g.runit, '') AS runit, "
        & "COALESCE(p.volum, 0) * CASE WHEN g.drcrk = 'H' THEN -1 ELSE 1 END / 100000 AS hl "
        & "FROM glpca g "
        & "JOIN vbrp p ON p.vbeln = g.refdocnr AND p.posnr = g.posnr "
        & "LEFT JOIN vbrk k ON k.vbeln = g.refdocnr "
        & "LEFT JOIN cuentas c ON c.cuenta = g.racct "
        & "LEFT JOIN excise e ON e.material = regexp_replace(p.matnr, '^0+', '') AND e.mes = CAST(date_trunc('MONTH', g.budat) AS DATE) ), "
        & "linea AS ( SELECT *, "
        & "CASE WHEN clase_cta = 'GSI' AND runit <> '' THEN hsl * -1 ELSE 0 END AS ingresos, "
        & "CASE WHEN clase_cta = 'GSI' AND runit = '' THEN hsl * -1 ELSE 0 END AS diff_price, "
        & "CASE WHEN clase_cta IN ('Desc_Precio', 'Desc_Trade', 'Desc_NCr', 'Desc_Rewards') THEN hsl ELSE 0 END AS desc_raw, "
        & "CASE WHEN clase_cta = 'GSI' AND runit <> '' AND util <> 'E5' THEN hl * -1 ELSE 0 END AS hl_vendido, "
        & "CASE WHEN clase_cta = 'Desc_Trade' AND util = 'E5' THEN hl ELSE 0 END AS hl_trade, "
        & "CASE WHEN clase_cta = 'Desc_Rewards' AND util = 'R4' AND runit <> '' THEN hl * -1 ELSE 0 END AS hl_rewards, "
        & "CASE WHEN cuenta IN ('S6241000T0', 'S624100ZT0', 'S624102HT0') "
        & "AND util IN ('D0', 'D6', 'D8', 'D9', 'D1', 'D2', 'D7', 'C2', 'D3', 'D4', 'D5', 'R4') THEN hl ELSE 0 END AS hl_btl "
        & "FROM base ) "
        & "SELECT dia AS invoice_date, cliente AS sold_to_customer_short_code, material AS product_short_code, "
        & "SUM(hl_vendido + hl_trade + hl_btl + hl_rewards) AS total_volume, "
        & "SUM((ingresos + diff_price) - desc_raw - CASE WHEN clase_cta IN ('GSI', 'Desc_Precio', 'Desc_Trade', 'Desc_Rewards') "
        & "THEN excise * (hl_vendido + hl_trade + hl_btl + hl_rewards) ELSE 0 END) AS net_revenue_amount, "
        & "CAST(NULL AS STRING) AS op_ind "
        & "FROM linea GROUP BY 1, 2, 3 "
        & "UNION ALL SELECT dia, cliente, material, hl, CAST(0 AS DOUBLE), CAST(NULL AS STRING) FROM pend",
    Datos = if hasta >= desde then Value.NativeQuery(Cat, Sql, null, [EnableFolding = false]) else Vacia
in
    Datos

// ============================================================================
// [Funciones] fnUltimoDiaSilver   (sin carga al modelo)
// ============================================================================
(desde as date, hasta as date) as nullable date =>
// DSR SILVER (v3): ultimo dia con ventas (cuentas GSI) en GLPCA de silver entre desde y hasta.
// Consulta liviana solo para el dia de referencia del reporte ('Refresh date').
let
    Origen = Databricks.Catalogs(DatabricksHost, DatabricksHttpPath, [Catalog = null, Database = null, EnableAutomaticProxyDiscovery = null]),
    Cat = Origen{[Name = "brewdat_uc_delta_maz_prod", Kind = "Database"]}[Data],
    Ini = Date.ToText(desde, [Format = "yyyy-MM-dd", Culture = "en-US"]),
    Fin = Date.ToText(hasta, [Format = "yyyy-MM-dd", Culture = "en-US"]),
    Sql = "SELECT MAX(CAST(budat AS DATE)) AS ultimo "
        & "FROM brewdat_uc_delta_maz_prod.slv_maz_finance_sap_pr3.copecac_glpca "
        & "WHERE rbukrs = 'DC00' AND budat BETWEEN '" & Ini & "' AND '" & Fin & "' "
        & "AND racct IN (SELECT gl_account_code FROM brewdat_uc_delta_maz_prod.slv_maz_masterdata_manual.pa_general_ledger_accounts "
        & "WHERE cognos_account_name = 'GSI')",
    Res = if hasta >= desde then Value.NativeQuery(Cat, Sql, null, [EnableFolding = false]) else null,
    Ultimo = if Res = null or Table.IsEmpty(Res) then null else Res{0}[ultimo]
in
    Ultimo

// ============================================================================
// [Funciones] fnPedidosSilver   (sin carga al modelo)
// ============================================================================
(desde as date, hasta as date) as table =>
// DSR SILVER: pedidos leidos de SAP silver (VBAK + VBAP) con la misma logica de pa_sales_order_detail:
// org. ventas DC01 / canal 01 / sector 00, sus 13 clases de pedido, ultima version de cada pedido y posicion,
// sin borrados, volumen VBAP / 100000 (HL), materiales 1000-99999. Fecha = fecha de creacion del pedido (VBAK.erdat).
// Devuelve las columnas que usa la consulta Pedidos.
let
    Vacia = #table(type table [order_creation_date = date, sales_document_type_code = text, customer_short_code = text,
        product_short_code = text, order_item_volume_hl = number], {}),
    Origen = Databricks.Catalogs(DatabricksHost, DatabricksHttpPath, [Catalog = null, Database = null, EnableAutomaticProxyDiscovery = null]),
    Cat = Origen{[Name = "brewdat_uc_delta_maz_prod", Kind = "Database"]}[Data],
    Ini = Date.ToText(desde, [Format = "yyyy-MM-dd", Culture = "en-US"]),
    Fin = Date.ToText(hasta, [Format = "yyyy-MM-dd", Culture = "en-US"]),
    Sql = "WITH k AS ( SELECT vbeln, erdat, auart, kunnr, op_ind, "
        & "ROW_NUMBER() OVER (PARTITION BY vbeln ORDER BY source_commit_ts DESC) AS rn "
        & "FROM brewdat_uc_delta_maz_prod.slv_maz_sales_sap_pr3.copecac_vbak "
        & "WHERE erdat BETWEEN '" & Ini & "' AND '" & Fin & "' AND vkorg = 'DC01' AND vtweg = '01' AND spart = '00' "
        & "AND auart IN ('ZND1', 'ZND3', 'ZND8', 'ZNDF', 'ZNO1', 'ZNOB', 'ZNP1', 'ZNPV', 'ZNSI', 'ZNRP', 'ZNE1', 'ZNO5', 'ZNNC') ), "
        & "p AS ( SELECT vbeln, posnr, matnr, volum, op_ind, "
        & "ROW_NUMBER() OVER (PARTITION BY vbeln, posnr ORDER BY source_commit_ts DESC) AS rn "
        & "FROM brewdat_uc_delta_maz_prod.slv_maz_sales_sap_pr3.copecac_vbap WHERE erdat >= '" & Ini & "' ) "
        & "SELECT CAST(k.erdat AS DATE) AS order_creation_date, k.auart AS sales_document_type_code, "
        & "regexp_replace(k.kunnr, '^0+', '') AS customer_short_code, regexp_replace(p.matnr, '^0+', '') AS product_short_code, "
        & "SUM(p.volum) / 100000 AS order_item_volume_hl "
        & "FROM k JOIN p ON p.vbeln = k.vbeln "
        & "WHERE k.rn = 1 AND p.rn = 1 "
        & "AND UPPER(TRIM(COALESCE(k.op_ind, ''))) NOT IN ('D', 'DELETE') "
        & "AND UPPER(TRIM(COALESCE(p.op_ind, ''))) NOT IN ('D', 'DELETE') "
        & "AND p.volum IS NOT NULL AND try_cast(p.matnr AS BIGINT) BETWEEN 1000 AND 99999 "
        & "GROUP BY 1, 2, 3, 4",
    Datos = if hasta >= desde then Value.NativeQuery(Cat, Sql, null, [EnableFolding = false]) else Vacia
in
    Datos

// ============================================================================
// [Funciones] HoyPanama   (sin carga al modelo)
// ============================================================================
Date.From(DateTimeZone.RemoveZone(DateTimeZone.SwitchZone(DateTimeZone.UtcNow(), -5)))

// ============================================================================
// [Funciones] MesRef   (sin carga al modelo)
// ============================================================================
// Primer dia del mes de reporte. El dia de referencia es el ultimo dia cargado en pa_invoice (normalmente ayer),
// por eso el mes sale de "ayer": el dia 1 el reporte sigue mostrando el mes que acaba de cerrar.
Date.StartOfMonth(Date.AddDays(HoyPanama, -1))

// ============================================================================
// [Tabla] Ventas Día
// ============================================================================
let
    // DSR SILVER v3: ventas a nivel DIA + cliente + material, dos tramos:
    //   - mes de reporte (ACT) desde SAP silver (fnVentasSilver): se actualiza varias veces al dia
    //   - mismo mes del anio pasado (LY) desde pa_invoice: historia ya validada, no cambia
    //   ACT = mes de reporte COMPLETO: incluye facturas con fecha futura (la facturacion de la noche sale con la
    //         fecha de entrega del dia siguiente), como el DSR oficial. El dia de referencia sigue siendo hoy ('Refresh date').
    //   LY  = el mismo mes completo del anio anterior
    // Filtro y agrupacion sobre las columnas crudas para que hagan query folding (comprobar con "Ver consulta nativa" en el paso Agrupado).
    TAct = fnVentasSilver(MesRef, FinAct),
    // LY desde pa_invoice, filtrado y agrupado en el origen (query folding), con las mismas columnas que fnVentasSilver
    Inv = fnTabla("brewdat_uc_delta_maz_prod", "gld_maz_sales_sell_in", "pa_invoice"),
    InvLY = Table.SelectRows(Inv, each [invoice_date] >= IniLY and [invoice_date] <= FinLY
        and ([op_ind] = null or ([op_ind] <> "D" and [op_ind] <> "DELETE"))),
    InvLYGrp = Table.Group(InvLY, {"invoice_date", "sold_to_customer_short_code", "product_short_code"},
        {{"total_volume", each List.Sum([total_volume]), type number}, {"net_revenue_amount", each List.Sum([net_revenue_amount]), type number}}),
    TLY = Table.AddColumn(InvLYGrp, "op_ind", each null, type nullable text),
    T = Table.Combine({TAct, TLY}),
    IniLY = Date.AddYears(MesRef, -1),
    FinLY = Date.EndOfMonth(IniLY),
    // Hasta el fin del mes de reporte (el dia 1 el reporte sigue mostrando el mes que cerro)
    FinAct = Date.EndOfMonth(MesRef),
    Ventana = Table.SelectRows(T, each ([invoice_date] >= MesRef and [invoice_date] <= FinAct) or ([invoice_date] >= IniLY and [invoice_date] <= FinLY)),
    SinBorrados = Table.SelectRows(Ventana, each [op_ind] = null or ([op_ind] <> "D" and [op_ind] <> "DELETE")),
    Agrupado = Table.Group(SinBorrados, {"invoice_date", "sold_to_customer_short_code", "product_short_code"},
        {{"hl", each List.Sum([total_volume]), type number}, {"nto", each List.Sum([net_revenue_amount]), type number}}),
    // (sin parche S624100ZT0 aqui: el mes de reporte viene de silver, que ya incluye esa cuenta)
    Tip = Table.TransformColumns(Agrupado, {{"invoice_date", fnFecha, type date}, {"sold_to_customer_short_code", fnCodigo, type text},
        {"product_short_code", fnCodigo, type text}, {"hl", Number.From, type number}, {"nto", Number.From, type number}}),
    Ren = Table.RenameColumns(Tip, {{"invoice_date", "Fecha"}, {"sold_to_customer_short_code", "customer_code"}}),
    Per = Table.AddColumn(Ren, "Periodo", each if [Fecha] >= MesRef then "ACT" else "LY", type text),
    // Fecha Reporte: el dia del anio anterior se muestra en la misma fecha de este anio (fecha + 1 anio), como el legado
    Rep = Table.AddColumn(Per, "Fecha Reporte", each if [Periodo] = "ACT" then [Fecha] else Date.AddYears([Fecha], 1), type date),
    Fin = Table.SelectColumns(Rep, {"Fecha", "Fecha Reporte", "Periodo", "customer_code", "product_short_code", "hl", "nto"})
in
    Fin

// ============================================================================
// [Tabla] Ventas Mes
// ============================================================================
let
    // pa_invoice a nivel MES + cliente + material, solo los meses CERRADOS que necesita el YTD:
    //   ACT = enero .. mes anterior al de reporte, de este anio
    //   LY  = enero .. el mismo mes anterior, del anio pasado
    // El mes de reporte (y el mismo mes del anio pasado) sale de 'Ventas Día'.
    T = fnTabla("brewdat_uc_delta_maz_prod", "gld_maz_sales_sell_in", "pa_invoice"),
    IniAct = #date(Date.Year(MesRef), 1, 1),
    IniLY = Date.AddYears(IniAct, -1),
    FinLY = Date.AddYears(MesRef, -1),
    Ventana = Table.SelectRows(T, each ([invoice_date] >= IniAct and [invoice_date] < MesRef) or ([invoice_date] >= IniLY and [invoice_date] < FinLY)),
    SinBorrados = Table.SelectRows(Ventana, each [op_ind] = null or ([op_ind] <> "D" and [op_ind] <> "DELETE")),
    Anio = Table.AddColumn(SinBorrados, "anio", each Date.Year([invoice_date]), Int64.Type),
    MesN = Table.AddColumn(Anio, "mes_n", each Date.Month([invoice_date]), Int64.Type),
    Agrupado = Table.Group(MesN, {"anio", "mes_n", "sold_to_customer_short_code", "product_short_code"},
        {{"hl", each List.Sum([total_volume]), type number}, {"nto", each List.Sum([net_revenue_amount]), type number}}),
    // >>> PARCHE TEMPORAL S624100ZT0: mismo volumen para los meses cerrados de este anio (ver fnParcheZT0)
    Zt0 = fnParcheZT0(IniAct, Date.AddDays(MesRef, -1)),
    Zt0Fecha = Table.TransformColumns(Zt0, {{"invoice_date", fnFecha, type date}}),
    Zt0Anio = Table.AddColumn(Zt0Fecha, "anio", each Date.Year([invoice_date]), Int64.Type),
    Zt0MesN = Table.AddColumn(Zt0Anio, "mes_n", each Date.Month([invoice_date]), Int64.Type),
    Zt0Mes = Table.Group(Zt0MesN, {"anio", "mes_n", "sold_to_customer_short_code", "product_short_code"},
        {{"hl", each List.Sum([hl]), type number}, {"nto", each List.Sum([nto]), type number}}),
    ConZt0 = Table.Combine({Agrupado, Zt0Mes}),
    Mes = Table.AddColumn(ConZt0, "Mes", each #date([anio], [mes_n], 1), type date),
    Per = Table.AddColumn(Mes, "Periodo", each if [anio] = Date.Year(MesRef) then "ACT" else "LY", type text),
    Tip = Table.TransformColumns(Per, {{"sold_to_customer_short_code", fnCodigo, type text}, {"product_short_code", fnCodigo, type text},
        {"hl", Number.From, type number}, {"nto", Number.From, type number}}),
    Ren = Table.RenameColumns(Tip, {{"sold_to_customer_short_code", "customer_code"}}),
    Fin = Table.SelectColumns(Ren, {"Mes", "Periodo", "customer_code", "product_short_code", "hl", "nto"})
in
    Fin

// ============================================================================
// [Tabla] Pedidos
// ============================================================================
let
    // DSR SILVER: pedidos desde SAP silver (fnPedidosSilver), fechados en FECHA DE PEDIDO + 1 (Fecha DSR), con el signo de Clases de Pedidos.
    T = fnPedidosSilver(Date.AddDays(MesRef, -1), Date.EndOfMonth(MesRef)),
    Sel = Table.SelectColumns(T, {"order_creation_date", "sales_document_type_code", "customer_short_code", "product_short_code", "order_item_volume_hl"}),
    Signos = [ZND1 = -1, ZND3 = -1, ZNDB = -1, ZNDF = -1, ZNNC = -1, ZNO1 = 1, ZNOB = 1, ZNO5 = 1, ZNP1 = 1, ZNPV = 1, ZNSI = 1],
    ConClase = Table.SelectRows(Sel, each [sales_document_type_code] <> null and Record.HasFields(Signos, [sales_document_type_code])),
    Tip = Table.TransformColumns(ConClase, {{"order_creation_date", fnFecha, type date}, {"customer_short_code", fnCodigo, type text},
        {"product_short_code", fnCodigo, type text}, {"order_item_volume_hl", Number.From, type number}}),
    Hls = Table.AddColumn(Tip, "Hls", each [order_item_volume_hl] * Record.Field(Signos, [sales_document_type_code]), type number),
    Dsr = Table.AddColumn(Hls, "Fecha DSR", each if [order_creation_date] = null then null else Date.AddDays([order_creation_date], 1), type date),
    // Solo el mes de reporte: la tabla trae la ventana completa (desde el ultimo dia del mes anterior)
    DelMes = Table.SelectRows(Dsr, each [Fecha DSR] <> null and [Fecha DSR] >= MesRef and [Fecha DSR] <= Date.EndOfMonth(MesRef)),
    Grp = Table.Group(DelMes, {"Fecha DSR", "customer_short_code", "product_short_code"}, {{"Hls", each List.Sum([Hls]), type number}}),
    Ren = Table.RenameColumns(Grp, {{"customer_short_code", "customer_code"}})
in
    Ren

// ============================================================================
// [Tabla] Cuota
// ============================================================================
let
    // pa_sales_target_customer_material_current_month: cuota MENSUAL por cliente + material.
    // El mes sale de reference_year / reference_month; el reparto por dia lo hace la medida [Cuota].
    T = fnTabla("brewdat_uc_maz_prod", CuotaEsquema, "pa_sales_target_customer_material_current_month"),
    Sel = Table.SelectColumns(T, {"reference_year", "reference_month", "customer_code", "product_short_code", "macro_category", "target_hl"}),
    Tip = Table.TransformColumns(Sel, {
        {"reference_year", each Int64.From(Number.FromText(Text.Trim(Text.From(_)), "en-US")), Int64.Type},
        {"reference_month", each Int64.From(Number.FromText(Text.Trim(Text.From(_)), "en-US")), Int64.Type},
        {"customer_code", fnCodigo, type text}, {"product_short_code", fnCodigo, type text},
        {"macro_category", each if _ = null then null else Text.Trim(Text.From(_)), type text},
        // target_hl viene como texto con punto decimal
        {"target_hl", each if _ = null then null else Number.FromText(Text.Trim(Text.From(_)), "en-US"), type number}}),
    Mes = Table.AddColumn(Tip, "Mes", each #date([reference_year], [reference_month], 1), type date),
    Grp = Table.Group(Mes, {"Mes", "customer_code", "product_short_code", "macro_category"}, {{"cuota_hl", each List.Sum([target_hl]), type number}})
in
    Grp

// ============================================================================
// [Tabla] Curva Cuota
// ============================================================================
let
    // pa_sales_curve_daily_category_cluster: curva DIARIA de cuota por cluster + macro categoria.
    // Se usa solo como PESO por dia: peso = hl del dia / hl del mes, por macro categoria (sumando los clusters,
    // porque pa_customer no trae el cluster del cliente). La medida [Cuota] reparte la cuota mensual con ese peso.
    // El mes se toma de calendar_date (en la muestra, reference_year y reference_month vienen con los valores cruzados).
    T = fnTabla("brewdat_uc_maz_prod", "slv_maz_sales_manual", "pa_sales_curve_daily_category_cluster"),
    Sel = Table.SelectColumns(T, {"calendar_date", "macro_category", "target_hl"}),
    // calendar_date es texto dia/mes/anio, con o sin cero a la izquierda (23/03/2026, 2/3/2026)
    Fec = Table.AddColumn(Sel, "Fecha", each
        let p = Text.Split(Text.Trim(Text.From([calendar_date])), "/") in
        try #date(Int64.From(Number.FromText(p{2}, "en-US")), Int64.From(Number.FromText(p{1}, "en-US")), Int64.From(Number.FromText(p{0}, "en-US"))) otherwise null, type date),
    Tip = Table.TransformColumns(Fec, {
        {"macro_category", each if _ = null then null else Text.Trim(Text.From(_)), type text},
        {"target_hl", each if _ = null then null else Number.FromText(Text.Trim(Text.From(_)), "en-US"), type number}}),
    Val = Table.SelectRows(Tip, each [Fecha] <> null),
    Dia = Table.Group(Val, {"Fecha", "macro_category"}, {{"target_hl", each List.Sum([target_hl]), type number}}),
    ConMes = Table.AddColumn(Dia, "Mes", each Date.StartOfMonth([Fecha]), type date),
    TotMes = Table.Group(ConMes, {"Mes", "macro_category"}, {{"hl_mes", each List.Sum([target_hl]), type number}}),
    Mrg = Table.NestedJoin(ConMes, {"Mes", "macro_category"}, TotMes, {"Mes", "macro_category"}, "t", JoinKind.LeftOuter),
    Exp = Table.ExpandTableColumn(Mrg, "t", {"hl_mes"}),
    Peso = Table.AddColumn(Exp, "peso", each if [hl_mes] = null or [hl_mes] = 0 then null else [target_hl] / [hl_mes], type number),
    Fin = Table.SelectColumns(Peso, {"Fecha", "Mes", "macro_category", "target_hl", "peso"})
in
    Fin

// ============================================================================
// [Tabla] Trading Days
// ============================================================================
let
    // pa_trading_days_calendar: 1 = dia habil de venta, 0 = domingo o feriado.
    // Mientras los parametros TradingDays* digan PENDIENTE la tabla sale vacia (las medidas por dia quedan en blanco).
    Vacia = #table(type table [Fecha = date, Dia Habil = Int64.Type], {}),
    Datos =
        let
            T = fnTabla(TradingDaysCatalogo, TradingDaysEsquema, "pa_trading_days_calendar"),
            Sel = Table.SelectColumns(T, {"date", "valid_trading_days_mtd"}),
            Tip = Table.TransformColumns(Sel, {{"date", fnFecha, type date}, {"valid_trading_days_mtd", Int64.From, Int64.Type}}),
            Ren = Table.RenameColumns(Tip, {{"date", "Fecha"}, {"valid_trading_days_mtd", "Dia Habil"}})
        in
            Ren
in
    if TradingDaysCatalogo = "PENDIENTE" or TradingDaysEsquema = "PENDIENTE" then Vacia else Datos

// ============================================================================
// [Tabla] Cliente
// ============================================================================
let
    // pa_customer (reemplaza dbo.SQVI): una fila por cliente; se prefiere la fila activa y mas reciente
    // (misma regla que pa_daily_sales_volume_report del equipo).
    // Region / Gerencia / Canal / Cluster salen de las tablas MANUALES del equipo, como el reporte oficial:
    //   Region y Gerencia: pa_client_commercial_management_hierarchy, por sales_subregion_code
    //   Canal:             pa_customer_channel_classification, por subchannel_code
    //   Cluster:           regla del equipo (ON VIP -> On Moderno; K.A -> Off Moderno; pa_wholesalers -> Mayoristas;
    //                      Off Tradicional / Distribuidores -> Minoristas; On Tradicional -> On Tradicional; resto -> Otros)
    T = fnTabla("brewdat_uc_delta_maz_prod", "gld_maz_masterdata_sales", "pa_customer"),
    PA = Table.SelectRows(T, each [country_code] = "PA"),
    Sel = Table.SelectColumns(PA, {"customer_short_code", "customer_name", "sales_subregion_code", "subchannel_code",
        "sales_zone_code", "distribution_center_name", "sales_area_name", "customer_status", "customer_updated_at"}),
    Cod = Table.AddColumn(Sel, "Cliente", each fnCodigo([customer_short_code]), type text),
    K = Table.AddColumn(Cod, "k", each if [customer_status] = "Active" then 0 else 1, Int64.Type),
    Ordenado = Table.Buffer(Table.Sort(K, {{"k", Order.Ascending}, {"customer_updated_at", Order.Descending}})),
    Unico = Table.Distinct(Table.SelectRows(Ordenado, each [Cliente] <> null and [Cliente] <> ""), {"Cliente"}),
    Llaves = Table.TransformColumns(Unico, {{"sales_subregion_code", each if _ = null then null else Text.Trim(Text.From(_)), type text},
        {"subchannel_code", each if _ = null then null else Text.Trim(Text.From(_)), type text}}),
    // Tablas manuales (una fila por llave)
    H = Table.SelectColumns(fnTabla("brewdat_uc_maz_prod", "slv_maz_masterdata_manual", "pa_client_commercial_management_hierarchy"),
        {"customer_group_code", "region_name", "commercial_management_name"}),
    HT = Table.Distinct(Table.TransformColumns(H, {{"customer_group_code", each if _ = null then null else Text.Trim(Text.From(_)), type text}}), {"customer_group_code"}),
    C = Table.SelectColumns(fnTabla("brewdat_uc_maz_prod", "slv_maz_masterdata_manual", "pa_customer_channel_classification"),
        {"channel_code", "channel_group_name"}),
    CT = Table.Distinct(Table.TransformColumns(C, {{"channel_code", each if _ = null then null else Text.Trim(Text.From(_)), type text}}), {"channel_code"}),
    W = Table.SelectColumns(fnTabla("brewdat_uc_maz_prod", "slv_maz_masterdata_manual", "pa_wholesalers"), {"customer_code"}),
    WT = Table.Distinct(Table.TransformColumns(W, {{"customer_code", fnCodigo, type text}})),
    J1 = Table.NestedJoin(Llaves, {"sales_subregion_code"}, HT, {"customer_group_code"}, "h", JoinKind.LeftOuter),
    E1 = Table.ExpandTableColumn(J1, "h", {"region_name", "commercial_management_name"}),
    J2 = Table.NestedJoin(E1, {"subchannel_code"}, CT, {"channel_code"}, "c", JoinKind.LeftOuter),
    E2 = Table.ExpandTableColumn(J2, "c", {"channel_group_name"}),
    J3 = Table.NestedJoin(E2, {"Cliente"}, WT, {"customer_code"}, "w", JoinKind.LeftOuter),
    E3 = Table.AddColumn(J3, "es_mayorista", each not Table.IsEmpty([w]), type logical),
    Clu = Table.AddColumn(E3, "Cluster", each
        let r = if [region_name] = null then "" else Text.Upper(Text.Trim([region_name])),
            c = if [channel_group_name] = null then "" else Text.Upper(Text.Trim([channel_group_name])) in
        if r = "ON VIP" then "On Moderno"
        else if r = "K.A" then "Off Moderno"
        else if not [es_mayorista] and List.Contains({"OFF TRADICIONAL", "DISTRIBUIDORES"}, c) then "Minoristas"
        else if [es_mayorista] then "Mayoristas"
        else if c = "ON TRADICIONAL" then "On Tradicional"
        else "Otros", type text),
    Dir = Table.AddColumn(Clu, "Dirección", each
        let a = if [sales_area_name] = null then "" else [sales_area_name] in
        if Text.Contains(a, "DirVenta KA") then "KA"
        else if Text.Contains(a, "DirVenta Este") or Text.Contains(a, "DirVenta Oeste") then "Tradicional"
        else if Text.Contains(a, "Clientes Internos") then "Cliente Interno"
        else null, type text),
    // Macro_Region: la misma regla del DSR legado (no se usa en las paginas)
    Mac = Table.AddColumn(Dir, "Macro_Región", each
        let r = if [region_name] = null then "" else [region_name] in
        if r = "Metro" or r = "Chorrera" or r = "K.A" or Text.Contains(r, "Colón") then "City"
        else if r = "Interior Oeste" then "Oeste"
        else if r = "Interior Centrales" then "Centrales"
        else "Cliente Interno", type text),
    // Centro: solo los centros de distribucion de Panama ("DC ..."); el resto queda en blanco
    // (algunos clientes fuera de las areas de venta traen centros de otros paises)
    Cen = Table.AddColumn(Mac, "Centro", each
        let c = [distribution_center_name] in if c <> null and Text.StartsWith(Text.Trim(c), "DC ") then Text.Trim(c) else null, type text),
    // Ruta (ZV) vacia se muestra como "No Data", como el reporte oficial
    Zv = Table.TransformColumns(Cen, {{"sales_zone_code", each if _ = null or Text.Trim(Text.From(_)) = "" then "No Data" else Text.Trim(Text.From(_)), type text}}),
    Ren = Table.RenameColumns(Zv, {{"customer_name", "Nombre"}, {"region_name", "Región"}, {"commercial_management_name", "Gerencia"},
        {"sales_zone_code", "ZV"}, {"channel_group_name", "Canal"}}),
    Fin = Table.SelectColumns(Ren, {"Cliente", "Nombre", "Dirección", "Región", "Macro_Región", "Gerencia", "ZV", "Centro", "Canal", "Cluster"}),
    Txt = Table.TransformColumnTypes(Fin, {{"Nombre", type text}, {"Región", type text}, {"Gerencia", type text}, {"ZV", type text},
        {"Centro", type text}, {"Canal", type text}, {"Cluster", type text}})
in
    Txt

// ============================================================================
// [Tabla] Material
// ============================================================================
let
    // pa_excise_rules (reemplaza dbo.Materiales): una fila por sku y por mes -> se toma el periodo mas reciente.
    T = fnTabla("brewdat_uc_delta_maz_prod", "slv_maz_masterdata_manual", "pa_excise_rules"),
    Sel = Table.SelectColumns(T, {"sku", "sku_name", "product_category", "category_group", "macro_category", "brand_local", "capacity",
        "pack_group", "package_size", "date_since"}),
    Cod = Table.AddColumn(Sel, "Material", each fnCodigo([sku]), type text),
    Ordenado = Table.Buffer(Table.Sort(Cod, {{"Material", Order.Ascending}, {"date_since", Order.Descending}})),
    Unico = Table.Distinct(Table.SelectRows(Ordenado, each [Material] <> null and [Material] <> ""), {"Material"}),
    Ren = Table.RenameColumns(Unico, {{"sku_name", "SKU-Local Name"}, {"product_category", "Product Category-Global"}, {"category_group", "Category Group"},
        {"macro_category", "Macro Category"}, {"brand_local", "Brand-Local"}, {"capacity", "Capacity"}, {"pack_group", "Pack Group"}, {"package_size", "Package Size"}}),
    // Las tres columnas derivadas que el reporte legado calculaba en Power Query / DAX
    PC = Table.AddColumn(Ren, "Product Category", each
        let g = [#"Product Category-Global"] in
        if List.Contains({"Beer", "CSD", "Malt", "Energizante"}, g) then g
        else if g = "Water" or g = "Water - MP" then "Water" else "Other", type text),
    Cat = Table.AddColumn(PC, "Categoría", each
        if [#"Product Category-Global"] = "CSD" or [#"Product Category-Global"] = "Malt" then "NABs" else [#"Product Category-Global"], type text),
    Mac = Table.AddColumn(Cat, "Macro", each
        if [Product Category] = "CSD" or [Product Category] = "Malt" then "Nabs" else [Product Category], type text),
    Fin = Table.SelectColumns(Mac, {"Material", "SKU-Local Name", "Product Category-Global", "Product Category", "Categoría", "Macro",
        "Category Group", "Macro Category", "Brand-Local", "Capacity", "Pack Group", "Package Size"}),
    Txt = Table.TransformColumnTypes(Fin, {{"SKU-Local Name", type text}, {"Product Category-Global", type text}, {"Category Group", type text},
        {"Macro Category", type text}, {"Brand-Local", type text}, {"Capacity", type text}, {"Pack Group", type text}, {"Package Size", type text}})
in
    Txt

// ============================================================================
// [Tabla] Calendario
// ============================================================================
let
    // Los dias del mes de reporte
    Fin = Date.EndOfMonth(MesRef),
    Lista = List.Dates(MesRef, Duration.Days(Fin - MesRef) + 1, #duration(1, 0, 0, 0)),
    Tab = Table.FromList(Lista, Splitter.SplitByNothing(), type table [Fecha = date]),
    Dia = Table.AddColumn(Tab, "Día del Mes", each Date.Day([Fecha]), Int64.Type),
    Esp = Table.AddColumn(Dia, "Español", each Text.Proper(Date.DayOfWeekName([Fecha], "es-PA")), type text),
    DLY = Table.AddColumn(Esp, "NombreDiaLY", each Date.DayOfWeekName(Date.AddYears([Fecha], -1), "es-PA"), type text),
    Mes = Table.AddColumn(DLY, "Inicio Mes", each Date.StartOfMonth([Fecha]), type date),
    Dom = Table.AddColumn(Mes, "Es Domingo", each Date.DayOfWeek([Fecha], Day.Monday) = 6, type logical)
in
    Dom

// ============================================================================
// [Tabla] Indicador
// ============================================================================
let
    Tab = #table(type table [KPI = text, Orden = Int64.Type], {{"Hls", 1}, {"NTO", 2}, {"NTO/Hls", 3}})
in
    Tab

// ============================================================================
// [Tabla] Días
// ============================================================================
let
    Tab = #table(type table [Días = text], {{"1. De Ventas"}, {"2. Transcurridos"}, {"3. Restantes"}})
in
    Tab

// ============================================================================
// [Tabla] Refresh date
// ============================================================================
let
    // Hora de Panama (UTC-5) y DIA DE REFERENCIA del reporte: el ultimo dia con ventas en SAP silver, HOY inclusive (fnUltimoDiaSilver).
    Ahora = DateTimeZone.RemoveZone(DateTimeZone.SwitchZone(DateTimeZone.UtcNow(), -5)),
    FinAct = List.Min({HoyPanama, Date.EndOfMonth(MesRef)}),
    Ultimo = fnFecha(fnUltimoDiaSilver(MesRef, FinAct)),
    Ref = if Ultimo = null then Date.AddDays(HoyPanama, -1) else Ultimo,
    Tab = #table(type table [Datetime = datetime, Date = date, Time = time, Fecha Ref = date], {{Ahora, Date.From(Ahora), Time.From(Ahora), Ref}})
in
    Tab

// ============================================================================
// [Tabla] Medidas
// ============================================================================
let
    Tab = #table(type table [Medida = text], {})
in
    Tab
