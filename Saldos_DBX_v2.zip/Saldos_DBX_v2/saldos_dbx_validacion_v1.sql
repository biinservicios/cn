-- =====================================================================================
-- Saldos_DBX v1 - validation vs the legacy report (SQL Server)
-- Run one query at a time and paste me all the results.
-- Databricks part: run with the Panama warehouse (brewdat-maz-maz-sales-pa-adbsql-p).
-- Compare D2 with L2 and D3 with L3 (same cut: OPEN items only).
-- =====================================================================================


-- =====================================================================================
-- DATABRICKS
-- =====================================================================================

-- D1. Status values in the new table (which value means "open"?)
SELECT item_open_cleared_status, COUNT(*) AS partidas, SUM(amount_local_currency) AS importe,
       MIN(posting_date) AS primera_contab, MAX(posting_date) AS ultima_contab
FROM brewdat_uc_maz_prod.gld_maz_finance_accounts_receivables.pa_accounts_receivable_line_item
GROUP BY item_open_cleared_status
ORDER BY item_open_cleared_status;

-- D2. OPEN items by ledger account (compare with L2)
SELECT posting_ledger_code AS lib_mayor, COUNT(*) AS partidas, SUM(amount_local_currency) AS importe
FROM brewdat_uc_maz_prod.gld_maz_finance_accounts_receivables.pa_accounts_receivable_line_item
WHERE upper(coalesce(trim(item_open_cleared_status), '')) <> 'C'
GROUP BY posting_ledger_code
ORDER BY posting_ledger_code;

-- D3. OPEN items by Region / Gerencia, same customer logic as the report (compare with L3)
WITH c AS (
    SELECT regexp_replace(trim(CAST(customer_short_code AS STRING)), '^0+', '') AS cliente,
           trim(CAST(sales_subregion_code AS STRING)) AS subregion,
           ROW_NUMBER() OVER (PARTITION BY regexp_replace(trim(CAST(customer_short_code AS STRING)), '^0+', '')
                              ORDER BY CASE WHEN customer_status = 'Active' THEN 0 ELSE 1 END,
                                       customer_updated_at DESC, sales_organization_code DESC) AS rn
    FROM brewdat_uc_delta_maz_prod.gld_maz_masterdata_sales.pa_customer
    WHERE country_code = 'PA'
),
h AS (
    SELECT trim(CAST(customer_group_code AS STRING)) AS k, region_name, commercial_management_name,
           ROW_NUMBER() OVER (PARTITION BY trim(CAST(customer_group_code AS STRING))
                              ORDER BY region_name, commercial_management_name) AS rn
    FROM brewdat_uc_maz_prod.slv_maz_masterdata_manual.pa_client_commercial_management_hierarchy
),
cli AS (
    SELECT c.cliente,
           COALESCE(h.region_name, CASE WHEN c.subregion = '90' THEN 'Cliente Interno' END) AS region,
           COALESCE(h.commercial_management_name, CASE WHEN c.subregion = '90' THEN 'Cliente Interno' END) AS gerencia
    FROM c LEFT JOIN h ON h.k = c.subregion AND h.rn = 1
    WHERE c.rn = 1
),
ar AS (
    SELECT regexp_replace(trim(customer_account_number), '^0+', '') AS cuenta, amount_local_currency AS importe
    FROM brewdat_uc_maz_prod.gld_maz_finance_accounts_receivables.pa_accounts_receivable_line_item
    WHERE upper(coalesce(trim(item_open_cleared_status), '')) <> 'C'
)
SELECT cli.region, cli.gerencia, COUNT(*) AS partidas, SUM(ar.importe) AS importe
FROM ar LEFT JOIN cli ON cli.cliente = ar.cuenta
GROUP BY cli.region, cli.gerencia
ORDER BY cli.region, cli.gerencia;

-- D4. OPEN items whose customer is NOT in pa_customer (they would show blank Region/Gerencia)
WITH c AS (
    SELECT DISTINCT regexp_replace(trim(CAST(customer_short_code AS STRING)), '^0+', '') AS cliente
    FROM brewdat_uc_delta_maz_prod.gld_maz_masterdata_sales.pa_customer
    WHERE country_code = 'PA'
)
SELECT regexp_replace(trim(ar.customer_account_number), '^0+', '') AS cuenta,
       COUNT(*) AS partidas, SUM(ar.amount_local_currency) AS importe
FROM brewdat_uc_maz_prod.gld_maz_finance_accounts_receivables.pa_accounts_receivable_line_item ar
LEFT JOIN c ON c.cliente = regexp_replace(trim(ar.customer_account_number), '^0+', '')
WHERE upper(coalesce(trim(ar.item_open_cleared_status), '')) <> 'C'
  AND c.cliente IS NULL
GROUP BY 1
ORDER BY ABS(SUM(ar.amount_local_currency)) DESC
LIMIT 30;

-- D5. CLEARED items by posting year (to decide whether the report should also load them)
SELECT year(posting_date) AS anio, COUNT(*) AS partidas
FROM brewdat_uc_maz_prod.gld_maz_finance_accounts_receivables.pa_accounts_receivable_line_item
WHERE upper(coalesce(trim(item_open_cleared_status), '')) = 'C'
GROUP BY 1
ORDER BY 1;


-- =====================================================================================
-- SQL SERVER (WarehousePanama)
-- =====================================================================================

-- L1. Date of the last legacy load (the legacy aging is calculated on that date)
SELECT MAX(TRY_CAST([Fe.contab.] AS DATE)) AS ultima_contab, MAX(TRY_CAST([Fecha doc.] AS DATE)) AS ultima_fecha_doc
FROM WarehousePanama.dbo.COBROS;

-- L2. OPEN items by ledger account (compare with D2)
SELECT [Lib.mayor] AS lib_mayor, COUNT(*) AS partidas, SUM(TRY_CAST([Importe en ML] AS DECIMAL(18, 2))) AS importe
FROM WarehousePanama.dbo.COBROS
WHERE [Estatus] = 'A'
GROUP BY [Lib.mayor]
ORDER BY [Lib.mayor];

-- L3. OPEN items by Region / Gerencia (compare with D3)
SELECT s.[Región] AS region, s.[Gerencia] AS gerencia, COUNT(*) AS partidas,
       SUM(TRY_CAST(c.[Importe en ML] AS DECIMAL(18, 2))) AS importe
FROM WarehousePanama.dbo.COBROS c
LEFT JOIN WarehousePanama.dbo.SQVI s ON s.[Cliente] = c.[Cuenta]
WHERE c.[Estatus] = 'A'
GROUP BY s.[Región], s.[Gerencia]
ORDER BY s.[Región], s.[Gerencia];

-- L4. Cadena values in SQVI (where do they come from?)
SELECT [Cadena], COUNT(*) AS clientes
FROM WarehousePanama.dbo.SQVI
GROUP BY [Cadena]
ORDER BY COUNT(*) DESC;

-- L5. Customer status values in SQVI (legacy shows "Activo/Sin Plan de Visita"; Databricks shows "Active")
SELECT [Estatus], COUNT(*) AS clientes
FROM WarehousePanama.dbo.SQVI
GROUP BY [Estatus]
ORDER BY COUNT(*) DESC;

-- L6. How much cleared history the legacy table keeps
SELECT YEAR(TRY_CAST([Fe.contab.] AS DATE)) AS anio, COUNT(*) AS partidas
FROM WarehousePanama.dbo.COBROS
WHERE [Estatus] = 'C'
GROUP BY YEAR(TRY_CAST([Fe.contab.] AS DATE))
ORDER BY 1;
