-- =====================================================================================
-- Cero_Fallos_DBX v1 - checks before opening the report
-- Run in the Panama warehouse (brewdat-maz-sales-pa-adb-ep01-p), one query at a time.
-- =====================================================================================

-- C1. Can the Panama warehouse read the BEES table? (if this fails, paste me the error)
SELECT COUNT(*) AS filas, COUNT(DISTINCT account_id) AS clientes, MIN(date_model) AS desde, MAX(date_model) AS hasta,
       MAX(update_at) AS ultima_actualizacion
FROM brewdat_uc_maz_bees_1p_ds.delta_sharing.zero_failures_monthly_share
WHERE country = 'PA';

-- C2. 10 sample account_id (format must match the customer code without leading zeros, e.g. 13755854)
SELECT account_id, vendor_account_id, ddc, ddc_name, sales_region_name, sales_sub_region_name, date_model, range
FROM brewdat_uc_maz_bees_1p_ds.delta_sharing.zero_failures_monthly_share
WHERE country = 'PA'
LIMIT 10;

-- C3. Customers of the last month that are NOT found in pa_customer (they would show blank Region / Gerencia)
WITH z AS (
    SELECT DISTINCT account_id
    FROM brewdat_uc_maz_bees_1p_ds.delta_sharing.zero_failures_monthly_share
    WHERE country = 'PA'
      AND date_model = (SELECT MAX(date_model) FROM brewdat_uc_maz_bees_1p_ds.delta_sharing.zero_failures_monthly_share WHERE country = 'PA')
),
c AS (
    SELECT DISTINCT regexp_replace(trim(CAST(customer_short_code AS STRING)), '^0+', '') AS cliente
    FROM brewdat_uc_delta_maz_prod.gld_maz_masterdata_sales.pa_customer
    WHERE country_code = 'PA'
)
SELECT COUNT(*) AS clientes_mes, SUM(CASE WHEN c.cliente IS NULL THEN 1 ELSE 0 END) AS sin_match,
       slice(collect_list(CASE WHEN c.cliente IS NULL THEN z.account_id END), 1, 20) AS ejemplos_sin_match
FROM z LEFT JOIN c ON c.cliente = z.account_id;
