-- =====================================================================================
-- Venta Externa DBX v1 - validation: the exact query of the Power BI, for 2026
-- Run in the Panama warehouse (brewdat-maz-sales-pa-adb-ep01-p). Note how long it takes.
-- Expected (legacy dbo.venta_exportacion): 2 lines, invoices 9104003124 / 9104003125,
-- Ctd.facturada 16,800 / 19,600 ST, Importe -102,648 / -119,756 (total -222,404).
-- =====================================================================================
WITH g AS (
    SELECT drcrk, racct, refdocnr, CAST(refdocln AS INT) AS pos, hsl, budat, aubel, matnr, fkart, op_ind, __update_gmt_ts,
           ROW_NUMBER() OVER (PARTITION BY gl_sirid ORDER BY header__change_seq DESC) AS rn
    FROM brewdat_uc_delta_maz_prod.slv_maz_finance_sap_pr3.copecac_glpca
    WHERE __partition_column >= '202601' AND racct = 'S413101AT0' AND kokrs = '0600' AND budat >= '2026-01-01'
),
g1 AS ( SELECT * FROM g WHERE rn = 1 AND coalesce(op_ind, '') <> 'D' ),
p AS (
    SELECT vbeln, CAST(posnr AS INT) AS pos, fkimg, vrkme, pstyv,
           ROW_NUMBER() OVER (PARTITION BY vbeln, posnr ORDER BY erdat DESC) AS rn
    FROM brewdat_uc_delta_maz_prod.slv_maz_sales_sap_pr3.copecac_vbrp
    WHERE __partition_column >= '20251201' AND vbeln IN (SELECT refdocnr FROM g1)
),
k AS (
    SELECT vbeln, fkdat, kunrg, kunag, ROW_NUMBER() OVER (PARTITION BY vbeln ORDER BY erdat DESC) AS rn
    FROM brewdat_uc_delta_maz_prod.slv_maz_sales_sap_pr3.copecac_vbrk
    WHERE __partition_column >= '202512' AND vbeln IN (SELECT refdocnr FROM g1)
)
SELECT g1.drcrk AS dh, g1.racct AS cuenta, g1.refdocnr AS factura, lpad(CAST(g1.pos AS STRING), 6, '0') AS posicion,
       CAST(p.fkimg AS DOUBLE) AS ctd_facturada, p.vrkme AS um, ROUND(p.fkimg * 0.0852, 2) AS volumen,
       g1.aubel AS doc_ventas, regexp_replace(g1.matnr, '^0+', '') AS material,
       p.pstyv AS tpos, g1.fkart AS clfac, k.fkdat AS fecha_factura, regexp_replace(k.kunrg, '^0+', '') AS pagador,
       regexp_replace(k.kunag, '^0+', '') AS solic, CAST(g1.hsl AS DOUBLE) AS importe,
       from_utc_timestamp(g1.__update_gmt_ts, 'America/Panama') AS actualizado, g1.budat AS fe_contab,
       month(g1.budat) AS mes, year(g1.budat) AS anio
FROM g1
LEFT JOIN p ON p.vbeln = g1.refdocnr AND p.pos = g1.pos AND p.rn = 1
LEFT JOIN k ON k.vbeln = g1.refdocnr AND k.rn = 1
ORDER BY g1.budat, g1.refdocnr, g1.pos;
